import 'package:flutter/material.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/PresentationLayer/Views/Pages/mdm_tasks/mdm_dashboard.dart';

class MDMAppBar extends StatelessWidget implements PreferredSizeWidget {
  const MDMAppBar({super.key, required this.appBarName});
  final String appBarName;
  @override
  Widget build(BuildContext context) {
    return PreferredSize(
      preferredSize: const Size.fromHeight(50.0),
      child: AppBar(
        leading: Builder(
          builder: (context) {
            return IconButton(
              icon: const Icon(
                // Icons.menu,
                Icons.home,
                color: Colors.white,
              ),
              onPressed: () {
                print('Home is tapped');
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => (const MDMDashboard())));
              },
            );
          },
        ),
        backgroundColor: Colors.blueAccent,
        title: Text(
          appBarName,
          style: const TextStyle(
              color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        actions: <Widget>[
          //       TextButton(
          //   onPressed: () {},
          //   child: const Icon(Icons.person, color: Colors.white,),
          // ),
          TextButton(
            onPressed: () {},
            child: const Icon(
              Icons.info,
              color: Colors.white,
            ),
          ),
          TextButton(
            onPressed: () {},
            child: const Icon(
              Icons.settings,
              color: Colors.white,
            ),
          ),
          TextButton(
            onPressed: () {},
            child: const Icon(
              Icons.logout,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  @override
  // TODO: implement preferredSize
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
