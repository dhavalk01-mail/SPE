import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/PresentationLayer/Views/Pages/mdm_tasks/drawer/mdm_drawer.dart';

import 'package:http/http.dart' as http;
import 'package:learning_mvvm_clean_architecture/features/dashboard/PresentationLayer/Views/Pages/mdm_tasks/mdmLogin.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/PresentationLayer/Views/Pages/mdm_tasks/mdm_app_bar.dart';
import 'dart:convert';

import 'package:learning_mvvm_clean_architecture/features/dashboard/PresentationLayer/Views/Pages/mdm_tasks/mdm_enrollment_details.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/PresentationLayer/Views/Pages/mdm_tasks/mdm_user.dart';

class MDMDataToShow {
  var totalProduct = 0;
  var skipProduct = 0;
  var limitProduct = 0;
}

Future<MDMDataToShow> getDashboardNumbers() async {
  final response = await http.get(Uri.parse('https://dummyjson.com/products'));

  if (response.statusCode == 200) {
    // If the server did return a 200 OK response,
    // then parse the JSON.
    final respJSON = jsonDecode(response.body);
    final totalProduct = respJSON['total'] as int;
    final skipProduct = respJSON['skip'] as int;
    final limitProduct = respJSON['limit'] as int;
    var returnValue = MDMDataToShow();
    returnValue.totalProduct = totalProduct;
    returnValue.skipProduct = skipProduct;
    returnValue.limitProduct = limitProduct;
    return returnValue;
  } else {
    // If the server did not return a 200 OK response,
    // then throw an exception.
    throw Exception('Failed to load album');
  }
}

class MDMDashboard extends StatefulWidget {
  const MDMDashboard({super.key});

  @override
  State<MDMDashboard> createState() => _MDMDashboardState();
}

class _MDMDashboardState extends State<MDMDashboard> {
  late Future<MDMDataToShow> dataToShow;
  int currentPageIndex = 0;
  int _selectedIndex = 0;
  static const TextStyle optionStyle =
      TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  static const List<Widget> _widgetOptions = <Widget>[
    Text(
      'Index 0: Home',
      style: optionStyle,
    ),
    Text(
      'Index 1: Settings',
      style: optionStyle,
    ),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  void initState() {
    super.initState();
    dataToShow = getDashboardNumbers();
  }

  @override
  Widget build(BuildContext context) {
    Theme.of(context);
    return MaterialApp(
      theme: ThemeData(useMaterial3: true),
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        drawer: const MDMDrawer(),
        appBar: const MDMAppBar(
          appBarName: 'Dashboard',
        ),
        bottomNavigationBar:
            /* BottomNavigationBar(
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.settings),
              label: 'Settings',
            ),
          ], 
          currentIndex: _selectedIndex,
          selectedItemColor: Colors.blue,
          onTap: _onItemTapped,
        ), */
            NavigationBar(
          onDestinationSelected: (int index) {
            setState(() {
              currentPageIndex = index;
            });
          },
          indicatorColor: Colors.blue,
          shadowColor: Colors.white,
          surfaceTintColor: Colors.black,
          selectedIndex: currentPageIndex,
          destinations: const <Widget>[
            NavigationDestination(
              selectedIcon: Icon(Icons.home),
              icon: Icon(Icons.home_outlined),
              label: 'Home',
            ),
            NavigationDestination(
              icon: Badge(child: Icon(Icons.settings)),
              label: 'Settings',
            ),
            // NavigationDestination(
            //   icon: Badge(
            //     label: Text('2'),
            //     child: Icon(Icons.messenger_sharp),
            //   ),
            //   label: 'Messages',
            // ),
          ],
        ),
        body: <Widget>[
          /// Home page
          FutureBuilder<MDMDataToShow>(
              future: dataToShow,
              builder: (BuildContext context,
                  AsyncSnapshot<MDMDataToShow> snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else {
                  if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  } else {
                    return SingleChildScrollView(
                      child: Container(
                        padding: const EdgeInsets.only(right: 10, left: 10),
                        child: Column(
                          children: [
                            const SizedBox(
                              height: 40,
                            ),
                            GridView(
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 2,
                                      childAspectRatio: (1 / 0.75)),
                              shrinkWrap: true,
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    print(
                                        'User tapped on Enrolled Devices Card');
                                  },
                                  child: Card(
                                    color: const Color.fromARGB(
                                        255, 233, 243, 248),
                                    child: Center(
                                      child: Column(
                                        children: [
                                          const SizedBox(
                                            height: 5,
                                          ),
                                          const Text(
                                            'Enrolled Devices',
                                            style: TextStyle(
                                              fontSize: 26,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.blue,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                            ' ${snapshot.data?.limitProduct}',
                                            style: const TextStyle(
                                                fontSize: 26,
                                                fontWeight: FontWeight.bold),
                                            textAlign: TextAlign.center,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () {
                                    print(
                                        'User tapped on In-Active Devices Card');
                                    late MDMUserDetailsService productService =
                                        MDMUserDetailsService();
                                    final sndk =
                                        productService.fetchUserDetails(17);
                                    final ApiMDMUserDataSource asdjh =
                                        ApiMDMUserDataSource();
                                    late Future<MDMUser> lasan =
                                        asdjh.getUserDetails(1);
                                    print(lasan);
                                  },
                                  child: Card(
                                    color: const Color.fromARGB(
                                        255, 233, 243, 248),
                                    child: Center(
                                      child: Column(
                                        children: [
                                          const SizedBox(
                                            height: 5,
                                          ),
                                          const Text(
                                            'Inactive Devices',
                                            style: TextStyle(
                                              fontSize: 26,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.blue,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          Text(' ${snapshot.data?.skipProduct}',
                                              style: const TextStyle(
                                                  fontSize: 26,
                                                  fontWeight: FontWeight.bold)),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () {
                                    print(
                                        'User tapped on Pending Enrollment Card');
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                (const MDMEnrollmentDetails())));
                                  },
                                  child: Card(
                                    color: const Color.fromARGB(
                                        255, 233, 243, 248),
                                    child: Center(
                                      child: Column(
                                        children: [
                                          const SizedBox(
                                            height: 5,
                                          ),
                                          const Text(
                                            'Enrollment pending',
                                            style: TextStyle(
                                              fontSize: 26,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.blue,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                              ' ${snapshot.data?.totalProduct}',
                                              style: const TextStyle(
                                                  fontSize: 26,
                                                  fontWeight: FontWeight.bold)),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () {
                                    print(
                                        'User tapped on Enrolled Devices Card');
                                  },
                                  child: Card(
                                    color: const Color.fromARGB(
                                        255, 233, 243, 248),
                                    child: Center(
                                      child: Column(
                                        children: [
                                          const SizedBox(
                                            height: 5,
                                          ),
                                          const Text(
                                            'Enrolled Devices',
                                            style: TextStyle(
                                              fontSize: 26,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.blue,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                              ' ${snapshot.data?.limitProduct}',
                                              style: const TextStyle(
                                                  fontSize: 26,
                                                  fontWeight: FontWeight.bold)),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                /*  Card(
                        color: const Color.fromARGB(255, 233, 243, 248),
                        child: Center(
                          child: Column(
                            children: [
                              const Text(
                                'Devices with blocklisted apps',
                                style: TextStyle(
                                  fontSize: 26,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Text(' $_enrolledDevice',
                                  style: const TextStyle(
                                      fontSize: 26, fontWeight: FontWeight.bold)),
                            ],
                          ),
                        ),
                      ),
                    */
                              ],
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            Container(
                              height: 50,
                              color: const Color.fromARGB(255, 233, 243, 248),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Text('Devices with blocklisted apps',
                                      style: TextStyle(
                                          color: Colors.blue,
                                          fontSize: 22,
                                          fontWeight: FontWeight.bold)),
                                  const SizedBox(
                                    width: 20,
                                  ),
                                  Text(
                                    '${snapshot.data?.totalProduct}',
                                    style: const TextStyle(
                                        fontSize: 26,
                                        fontWeight: FontWeight.bold),
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }
                }
              }),

          /// Notifications page
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: Column(
              children: <Widget>[
                Card(
                  child: ListTile(
                    leading: Icon(Icons.notifications_sharp),
                    title: Text('Notification 1'),
                    subtitle: Text('This is a notification'),
                  ),
                ),
                Card(
                  child: ListTile(
                    leading: Icon(Icons.notifications_sharp),
                    title: Text('Notification 2'),
                    subtitle: Text('This is a notification'),
                  ),
                ),
              ],
            ),
          ),
        ][currentPageIndex],
      ),
      /*AppBar(
          leading: Builder(
            builder: (context) {
              return IconButton(
                icon: const Icon(
                  // Icons.menu,
                  Icons.home,
                  color: Colors.white,
                ),
                onPressed: () {
                  //  Scaffold.of(context).openDrawer();
                  if (ModalRoute.of(context)?.isCurrent ?? false) {
                    // Run your function here
                    print('Home on top');
                  } else {
                    print('Home NOT on top');
                  }
                },
              );
            },
          ),
          backgroundColor: Colors.blueAccent,
          title: const Text(
            'Dashboard',
            style: TextStyle(
                color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
          ),
          centerTitle: true,
          actions: <Widget>[
            //       TextButton(
            //   onPressed: () {},
            //   child: const Icon(Icons.person, color: Colors.white,),
            // ),
            TextButton(
              onPressed: () {},
              child: const Icon(
                Icons.info,
                color: Colors.white,
              ),
            ),
            TextButton(
              onPressed: () {},
              child: const Icon(
                Icons.settings,
                color: Colors.white,
              ),
            ),
            TextButton(
              onPressed: () {},
              child: const Icon(
                Icons.logout,
                color: Colors.white,
              ),
            ),
          ],
        ), */
    );
  }
}



/*

 const SizedBox(
                            height: 20,
                          ),
                          Container(
                            color: const Color.fromARGB(255, 233, 243, 248),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Text('Enrolled Devices',
                                    style: TextStyle(
                                        color: Colors.blue,
                                        fontSize: 30,
                                        fontWeight: FontWeight.bold)),
                                const SizedBox(
                                  width: 20,
                                ),
                                Text(
                                  '999',
                                  style: const TextStyle(
                                      fontSize: 30,
                                      fontWeight: FontWeight.bold),
                                )
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          Container(
                            color: const Color.fromARGB(255, 233, 243, 248),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Text('Inactive Devices',
                                    style: TextStyle(
                                        color: Colors.blue,
                                        fontSize: 30,
                                        fontWeight: FontWeight.bold)),
                                const SizedBox(
                                  width: 20,
                                ),
                                Text(
                                  '567',
                                  style: const TextStyle(
                                      fontSize: 30,
                                      fontWeight: FontWeight.bold),
                                )
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          Container(
                            color: const Color.fromARGB(255, 233, 243, 248),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Text('Enrollment Pending',
                                    style: TextStyle(
                                        color: Colors.blue,
                                        fontSize: 30,
                                        fontWeight: FontWeight.bold)),
                                const SizedBox(
                                  width: 20,
                                ),
                                Text(
                                  '456',
                                  style: const TextStyle(
                                      fontSize: 30,
                                      fontWeight: FontWeight.bold),
                                )
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          Container(
                            color: const Color.fromARGB(255, 233, 243, 248),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Text('Enrolled Users',
                                    style: TextStyle(
                                        color: Colors.blue,
                                        fontSize: 30,
                                        fontWeight: FontWeight.bold)),
                                const SizedBox(
                                  width: 20,
                                ),
                                Text(
                                  '231',
                                  style: const TextStyle(
                                      fontSize: 30,
                                      fontWeight: FontWeight.bold),
                                )
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          Container(
                            color: const Color.fromARGB(255, 233, 243, 248),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Text('Devices with blocklisted apps',
                                    style: TextStyle(
                                        color: Colors.blue,
                                        fontSize: 22,
                                        fontWeight: FontWeight.bold)),
                                const SizedBox(
                                  width: 20,
                                ),
                                Text(
                                  '54',
                                  style: const TextStyle(
                                      fontSize: 26,
                                      fontWeight: FontWeight.bold),
                                )
                              ],
                            ),
                          ),
                          
       
*/