import 'package:flutter/material.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/PresentationLayer/Views/Pages/mdm_tasks/mdm_app_bar.dart';

class MDMEnrollmentDetails extends StatefulWidget {
  const MDMEnrollmentDetails({super.key});

  @override
  State<MDMEnrollmentDetails> createState() => _MDMEnrollmentDetailsState();
}

class _MDMEnrollmentDetailsState extends State<MDMEnrollmentDetails> {
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: MDMAppBar(
          appBarName: 'Enrollment Details',
        ),
        body: Center(
          child: Text('This is the Enrollment Details page'),
        ),
      ),
    );
  }
}
