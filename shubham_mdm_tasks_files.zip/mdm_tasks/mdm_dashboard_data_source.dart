import 'dart:convert';
import 'dart:ffi';

import 'package:http/http.dart' as http;

class MDMDataToShow {
  var totalProduct = 0;
  var skipProduct = 0;
  var limitProduct = 0;
}

class MDMDashboardDataSource {
  Future<MDMDataToShow> getDashboardNumbers() async {
    final response =
        await http.get(Uri.parse('https://dummyjson.com/products'));

    if (response.statusCode == 200) {
      // If the server did return a 200 OK response,
      // then parse the JSON.
      final respJSON = jsonDecode(response.body);
      final totalProduct = respJSON['total'] as int;
      final skipProduct = respJSON['skip'] as int;
      final limitProduct = respJSON['limit'] as int;
      var returnValue = MDMDataToShow();
      returnValue.totalProduct = totalProduct;
      returnValue.skipProduct = skipProduct;
      returnValue.limitProduct = limitProduct;
      return returnValue;
    } else {
      // If the server did not return a 200 OK response,
      // then throw an exception.
      throw Exception('Failed to load album');
    }
  }
}
