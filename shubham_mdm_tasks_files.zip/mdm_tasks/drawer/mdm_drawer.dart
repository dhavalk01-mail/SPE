import 'package:flutter/material.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/PresentationLayer/Views/Pages/mdm_tasks/mdm_dashboard.dart';

class MDMDrawer extends StatelessWidget {
  const MDMDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          const DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.blue,
            ),
            child: Text('Welcome User Name',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold)),
          ),
          ListTile(
            title: const Text('Home'),
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => const MDMDashboard()));
            },
          ),
          ListTile(
            title: const Text('Profile'),
            onTap: () {
              // Then close the drawer
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }
}
