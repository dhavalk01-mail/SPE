import 'dart:convert';
import 'dart:ffi';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:learning_mvvm_clean_architecture/features/dashboard/PresentationLayer/Views/Pages/mdm_tasks/mdm_user.dart';

class MDMUserDetailsService {
  Future<dynamic> fetchUserDetails(int id) async {
    final response =
        await http.get(Uri.parse('http://dummyjson.com/users/$id'));
    //''http://dummyjson.com/users/1'
    //'https://api-generator.retool.com/aWh4OU/data/$id'
    if (response.statusCode == 200) {
      // If the server did return a 200 OK response,
      // then parse the JSON.
      final respJSON = jsonDecode(response.body);
      return respJSON;
    } else {
      // If the server did not return a 200 OK response,
      // then throw an exception.
      throw Exception(
          'Failed to get MDM Login response with status code ${response.statusCode}');
    }
  }
}

abstract class MDMUserDataSource {
  Future<MDMUser> getUserDetails(int id);
}

class ApiMDMUserDataSource implements MDMUserDataSource {
  late MDMUserDetailsService mdmService = MDMUserDetailsService();

  @override
  Future<MDMUser> getUserDetails(int id) async {
    try {
      final productJSON = await mdmService.fetchUserDetails(id);
      final parsedJSON = productJSON as Map<String, dynamic>;
      final userDetails = MDMUser.fromJson(parsedJSON);
      return userDetails;
    } on SocketException {
      throw Exception('No Internet Connection');
    }
  }
}
