import 'package:flutter/material.dart';
import 'package:learning_mvvm_clean_architecture/dependency_injection.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/PresentationLayer/Views/Root/MyApp.dart';
import 'package:provider/provider.dart';  
import 'dart:io';

class MyHttpOverrides extends HttpOverrides{
  @override
  HttpClient createHttpClient(SecurityContext? context){
    return super.createHttpClient(context)
      ..badCertificateCallback = (X509Certificate cert, String host, int port)=> true;
  }
}


void main() async {
  
 // HttpOverrides.global = MyHttpOverrides();
 // WidgetsFlutterBinding.ensureInitialized(); 
  final di = DependencyInjectionApp();

  runApp(  
    MultiProvider(
      providers: [
       ChangeNotifierProvider(create: (_) => di.initiaiseDashboardDependencies()), 
      ],
      child: const MyApp(),
     ),
    );
}
 


  