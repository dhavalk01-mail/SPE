/*

The View Layer in MVVVM presents the Presentation Layer in Flutter Clean Archtecture
ViewModel represents the Domain Layer
Model layer represents Data Layer

1- Presentation Layer

Responsibility------------------------------------------
The Presentation Layer is the outermost layer, 
responsible for presenting information to the user and capturing user interactions.
It includes all the components related to the user interface (UI), such as widgets, screens,
 and presenters/controllers (State Management).

*/