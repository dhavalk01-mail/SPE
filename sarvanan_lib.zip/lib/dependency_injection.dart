
import 'package:learning_mvvm_clean_architecture/features/dashboard/DataLayer/DataSources/Remote/api_product_data_source.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/DataLayer/Repository/ProductRepository.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/DomainLayer/UseCases/products_use_case.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/PresentationLayer/viewmodel/products_view_model.dart';



class DependencyInjectionApp { 
  
   ProductViewModel   initiaiseDashboardDependencies() {
     // Dependency injection setup for dashboard
     final productDataSource = ApiProductDataSource(); 
     final repo = ProductRepository(productDataSource: productDataSource);
     final productUseCase = ProductUseCase(productRepository: repo);
     final productViewModel = ProductViewModel(productUseCase: productUseCase); 
     productViewModel.fetchProductsList();  
     print(productViewModel.productArr);
     return productViewModel; 
   }
  
}