import 'package:flutter/material.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/DataLayer/DataModels/products_response_model.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/PresentationLayer/Views/Pages/productdetail.dart'; 
import 'package:learning_mvvm_clean_architecture/features/dashboard/PresentationLayer/viewmodel/products_view_model.dart';
import 'package:provider/provider.dart';

class ProductsPage extends StatefulWidget {
  const ProductsPage({super.key}); 
  @override
  State<ProductsPage> createState() => _ProductsPageState(); 
}

class _ProductsPageState extends State<ProductsPage> { 
     
  late List<Product>? _prodArr;
  var prodFuture; 
  
  @override
  Widget build(BuildContext context) {  
    prodFuture = Provider.of<ProductViewModel>(context);
    prodFuture.fetchProductsList();     
    _prodArr = prodFuture.productArr;
    print(_prodArr);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Products',
      home: Scaffold( 
          body: //_prodArr!.isEmpty ? 
          ListView.builder(
            itemCount: _prodArr?.length,  
            shrinkWrap: true ,      
            itemBuilder: (context, index) { 
                return  ListTile( 
                  onTap: () {
                        Navigator.push(context,
                   MaterialPageRoute(builder: (context) => (ProductDetails(productToShow: _prodArr![index],))));
                    },
                  leading:  AspectRatio(
          aspectRatio: 1,
          child: ClipRRect(
            borderRadius: const BorderRadius.all(Radius.circular(4.0)),
            child: Image.network(_prodArr![index].thumbnail!, height: 40, width: 40,
              fit: BoxFit.cover,
            ),
          ),
                ), 
            title:  Text(_prodArr![index].title!, style: const TextStyle(fontSize: 14)),
            subtitle: Text('Price : ${_prodArr![index].price}', style: const TextStyle(fontWeight: FontWeight.bold)),
                 // trailing: Text(snapshot.data![index].description!, style: const TextStyle(fontSize: 10)),
            ); 
          }) //: const Center(child: CircularProgressIndicator()), //const Text('Loading data...'),
        ),
      ); 
  }
}

















/*
 @override
  Widget build(BuildContext context) { 
   final productsVM = Provider.of<ProductViewModel>(context);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: FutureBuilder<List<Product>>(
          future: productsVM.productArr!,
          builder: (context, snapshot) {
            if (snapshot.hasData) {
        return ListView.builder(
          itemCount: snapshot.data!.length,        
          itemBuilder: (context, index) { 
              return  ListTile( 
                onTap: () {
          //  final selectedCell = snapshot.data![index].title;
            
              /*   if (Platform.isIOS) { 
                    CupertinoAlertDialog(
                          title: const Text('Tapped on'), 
                          content: Text('$selectedCell'),
                          actions: const [CupertinoDialogAction(child: Text('Okay'))],
                    );
                  }  else {
                       showDialog(context: context, builder: (context) {
                          return  AlertDialog(
                             title: const Text('Tapped on'), 
                          content: Text('$selectedCell'),
                          actions: const [CupertinoDialogAction(child: Text('Okay'))],
                          );
                       });   
                  }
                  */
                    // Navigator.push(context,
                    //  MaterialPageRoute(builder: (context) => (ProductDetails(product: snapshot.data![index]))));
                },
                leading:  AspectRatio(
        aspectRatio: 1,
        child: ClipRRect(
          borderRadius: const BorderRadius.all(Radius.circular(4.0)),
          child: Image.network(snapshot.data![index].thumbnail!, height: 40, width: 40,
            fit: BoxFit.cover,
          ),
        ),
      ), 
          title:  Text(snapshot.data![index].title!, style: const TextStyle(fontSize: 14)),
          subtitle: Text('Price : ${snapshot.data![index].price!}', style: const TextStyle(fontWeight: FontWeight.bold)),
       // trailing: Text(snapshot.data![index].description!, style: const TextStyle(fontSize: 10)),
          )
          ;
           
        });
            } else if (snapshot.hasError) {
        return Text('${snapshot.error}');
            } 
            // By default, show a loading spinner.
            return const CircularProgressIndicator();
          },
        ),
      )
       
    );
  }
    
  
*/