import 'package:flutter/material.dart'; 
import 'package:learning_mvvm_clean_architecture/features/dashboard/DataLayer/DataModels/products_response_model.dart';

class ProductDetails extends StatelessWidget {
  const ProductDetails({super.key, required this.productToShow});

  final Product productToShow;
  
  @override
  Widget build(BuildContext context) { 
    return MaterialApp(
      title: 'Product Details',
       debugShowCheckedModeBanner: false,
       home: Scaffold( 
        appBar: AppBar(title:
        Text(productToShow.title!),), 
        body: Column( 
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Flexible( 
              child: GridView.builder(gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 6),
              itemCount: productToShow.images!.length, 
              shrinkWrap: true,
              itemBuilder: (context, index) {
                   return Image.network(productToShow.images![index],);
              }),
            ),
            const SizedBox(height: 20,),
            Text(productToShow.title!, textAlign: TextAlign.left,),
            Text('Price : ${productToShow.price!}'),
            Text(productToShow.description!),
            const SizedBox(height: 40,),
          ],
        ),),
    );
  }
}
 