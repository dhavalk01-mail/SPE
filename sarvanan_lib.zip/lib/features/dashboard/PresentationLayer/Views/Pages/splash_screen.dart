import 'package:flutter/material.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/PresentationLayer/Views/Pages/ProductsPage.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _MyWidgetState();

  
}

class _MyWidgetState extends State<SplashScreen> {

 startTime() async {
    var duration = const Duration(seconds: 4);
    return Timer(duration, route);
  }
 
@override
  void initState() { 
    super.initState();
    startTime();
  }
  
  route() {
    Navigator.pushReplacement(context, MaterialPageRoute(
        builder: (context) => const ProductsPage()
      )
    ); 
  }
  @override
  Widget build(BuildContext context) {
    return const Material(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            "Initialization",
            style: TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 20),
          CircularProgressIndicator()
        ],
      ),
    );
  }
}