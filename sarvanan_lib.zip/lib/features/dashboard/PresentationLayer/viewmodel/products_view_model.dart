import 'package:flutter/material.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/DataLayer/DataModels/products_response_model.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/DomainLayer/UseCases/products_use_case.dart';

class ProductViewModel extends  ChangeNotifier {
  final ProductUseCase productUseCase;

  ProductViewModel({ required this.productUseCase});

   List<Product>? _productArr;
   List<Product>? get productArr => _productArr;

  void fetchProductsList() {
        productUseCase.getProducts().then((productArr) {
            _productArr = productArr;
            notifyListeners(); 
        }).catchError((error) { 
            throw Exception('****Failed to load Products in VIEW MODEL ${error.toString()}');
        });
    }  
  } 