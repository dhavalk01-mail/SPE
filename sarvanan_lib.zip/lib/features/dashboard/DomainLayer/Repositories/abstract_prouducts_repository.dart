
import 'package:learning_mvvm_clean_architecture/features/dashboard/DataLayer/DataModels/products_response_model.dart';

abstract class AbstractProductRepository {
   Future<List<Product>> getProducts();
}