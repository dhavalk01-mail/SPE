import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

abstract class UseCase<Type, Params> {
  // Future<Either<Failure, Type>> call(Params params);
  Future<Type> call({Params params});
}



abstract class Failure extends Equatable {
  @override
  List<Object> get props => [];
}