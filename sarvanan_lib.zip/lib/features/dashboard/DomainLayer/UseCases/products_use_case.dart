 
import 'package:dartz/dartz.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/DataLayer/DataModels/products_response_model.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/DataLayer/Repository/ProductRepository.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/DomainLayer/UseCases/abstract_use_case.dart';

class ProductUseCase {

     ProductUseCase({required this.productRepository}); 
     final ProductRepository productRepository;
             
     Future<List<Product>> getProducts()  {
        return productRepository.getProducts();
      }        
}
  