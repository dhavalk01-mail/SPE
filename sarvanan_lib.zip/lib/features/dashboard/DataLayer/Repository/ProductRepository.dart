import 'package:learning_mvvm_clean_architecture/features/dashboard/DataLayer/DataModels/products_response_model.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/DataLayer/DataSources/Remote/product_data_source.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/DomainLayer/Repositories/abstract_prouducts_repository.dart';
 
class ProductRepository implements AbstractProductRepository{
  final ProductDataSource productDataSource;
  ProductRepository({required this.productDataSource});
   
   @override
     Future<List<Product>> getProducts() {
     return productDataSource.getProducts();
  }
}

