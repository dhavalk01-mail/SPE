import 'dart:convert';
import 'dart:io'; 
import 'package:http/http.dart' as http; 

class ProductService {
  // final String _baseURL = 'https://dummyjson.com/';
  // final String _endPoint = 'products'; 
  final String _combo = 'https://dummyjson.com/products';
  Future<dynamic> getProductsJSON() async {
      dynamic responseJSON;  
      try {
        final response = await http.get(Uri.parse(_combo)); 
        if (response.statusCode == 200) {
           responseJSON = jsonDecode(response.body);
        } else {
           throw Exception('Failed to load Products');
        } 
      }  on SocketException   {
         throw Exception('No Internet Connection'); 
      }   
       return responseJSON;
  }
   
}





















/*
 Future<List<Product>> getProducts() async {
      final response = await http.get(Uri.parse('https://dummyjson.com/products'));
      if (response.statusCode == 200) {
         final bla =  ProductsResponse.fromJson(jsonDecode(response.body) as Map<String,dynamic>); 
         return  bla.products! ; 
      } else {
    // If the server did not return a 200 OK response,
    // then throw an exception.
    throw Exception('Failed to load album');
    }
   } 

*/