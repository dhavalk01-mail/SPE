import 'dart:io';

import 'package:learning_mvvm_clean_architecture/features/dashboard/DataLayer/DataModels/products_response_model.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/DataLayer/DataSources/Remote/product_data_source.dart';
import 'package:learning_mvvm_clean_architecture/features/dashboard/DataLayer/Service/ProductService.dart'; 



class ApiProductDataSource implements ProductDataSource {
  
  late ProductService productService = ProductService();
  
  @override
  Future<List<Product>> getProducts() async{ 
    try {
       final productJSON = await productService.getProductsJSON();
       final productList = productJSON['products'] as List;
       return productList.map((tagJson) => Product.fromJson(tagJson as Map<String, dynamic>)).toList();
    }   on SocketException   {
         throw Exception('No Internet Connection'); 
      }  

  }

}  































/*
  @override
  Future<List<Product>> getProducts() async { 
     const String baseURL = 'https://dummyjson.com/products'; 
      try {
        final response = await http.get(Uri.parse(baseURL)); 
        if (response.statusCode == 200) {
            final responseJSON = jsonDecode(response.body); 
             final productListJSON = responseJSON['products'] as List;
             List<Product> productList =  productListJSON.map((tagJson) => Product.fromJson(tagJson as Map<String, dynamic>)).toList();
          return  productList;
        } else {
           throw Exception('Failed to load Products');
        } 
      }  on SocketException   {
         throw Exception('No Internet Connection'); 
      }   
   
  }*/
  
  
