import os
from github import Github
from pathlib import Path
import pdb
#GitHub personal access token
#access_token = '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'
access_token = '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'
#GitHub username
username = 'harissm66'
#repository name
repository_name = 'My_Python_Repo'
#directory containing .sh files
directory_path = '/home/nexgencld02/Hari/My_Python_Repo-main'
# Replace with the commit message
commit_message = 'Add .sh files'
pdb.set_trace()
# Authenticate to GitHub
g = Github(access_token)

access_token = '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'
# Get the repository
repo = g.get_user(username).get_repo(repository_name)

# Iterate over all .sh files in the directory
for root, _, files in os.walk(directory_path):
    for file_name in files:
        if file_name.endswith('.sh'):
            file_path = os.path.join(root, file_name)
            print(file_path)
            with open(file_path, 'r') as file:
                content = file.read()

            # Create or update the file in the repository
            try:
                contents = repo.get_contents(file_name)
                # If the file exists, update it
                repo.update_file(contents.path, commit_message, content, contents.sha)
                print(f'{file_name} updated successfully.')
            except:
                # If the file does not exist, create it
                repo.create_file(file_name, commit_message, content)
                print(f'{file_name} created successfully.')

