from flask import Flask, request, jsonify
from typing import List, Dict

app = Flask(__name__)

class Task:
    def __init__(self, task_data):
        self.id = task_data["id"]
        self.type = task_data["type"]
        self.data = task_data["data"]
        self.position = task_data.get("position", {"x": 0, "y": 0})

    def execute(self):
        # Simulate task execution; replace with actual logic
        print(f"Executing task '{self.data['name']}' with command: {self.data['cmd']}")

class Edge:
    def __init__(self, edge_data):
        self.id = edge_data["id"]
        self.source = edge_data["source"]
        self.target = edge_data["target"]
        self.pre_condition = edge_data["Pre-condition"]

class Workflow:
    def __init__(self, workflow_data):
        self.id = workflow_data["id"]
        self.description = workflow_data["description"]
        self.owner = workflow_data["owner"]
        self.tasks = []
        self.edges = []

        # Create tasks
        for task_data in workflow_data["Tasks"]:
            task = Task(task_data)
            self.tasks.append(task)

        # Create edges
        for edge_data in workflow_data["Edges"]:
            edge = Edge(edge_data)
            self.edges.append(edge)

    def execute_workflow(self):
        # Execute tasks according to workflow edges
        for edge in self.edges:
            source_task = self.find_task_by_id(edge.source)
            target_task = self.find_task_by_id(edge.target)

            # Check pre-conditions
            if self.check_pre_conditions(source_task, edge.pre_condition):
                source_task.execute()
                target_task.execute()

    #def create_workflow(self):

    def find_task_by_id(self, task_id):
        for task in self.tasks:
            if task.id == task_id:
                return task
        return None

    def check_pre_conditions(self, task, pre_conditions):
        return True  

@app.route('/execute_workflow', methods=['POST'])
def execute_workflow():
    if request.method == 'POST':
        json_data = request.get_json()
        workflow = Workflow(json_data)
        workflow.execute_workflow()
        return jsonify({'message': 'Workflow executed successfully'}), 200
    else:
        return jsonify({'error': 'Method not allowed'}), 405

if __name__ == '__main__':
    app.run(debug=True)