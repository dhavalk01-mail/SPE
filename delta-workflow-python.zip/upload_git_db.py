from flask import Flask, request, jsonify
import json
import os
import psycopg2
from github import Github
from pathlib import Path
import pdb
import base64
import requests
from psycopg2 import sql

app = Flask(__name__)


def get_db_config(config_file):
    with open(config_file, 'r') as file:
        config = json.load(file)
    return config

db_config = get_db_config('Dbcred.json')

# Database connection parameters
DB_HOST = db_config['db_host']
DB_NAME = db_config['db_name']
DB_USER = db_config['db_user']
DB_PASSWORD = db_config['db_password']
DB_PORT = db_config['db_port']

def get_file_sha(github_owner, github_repo, script_path, headers):
    url = f"https://api.github.com/repos/{github_owner}/{github_repo}/contents/{script_path}"
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.json().get('sha')
    return None

def upload_scripts_to_github(json_data, github_token, github_repo, github_owner):
    headers = {
        "Authorization": f"token {github_token}",
        "Accept": "application/vnd.github.v3+json"
    }
    count=1
    for task in json_data["Tasks"]:
        
        #task_id = task["id"]
        task_id = execute_query("SELECT MAX(taskid) FROM tasks", fetch=True)[0][0] + 1
        print("taskid------------>",task_id)
        cmds = task["data"]["cmd"]
        query="INSERT INTO tasks (taskdetails) VALUES (%s)"
        
        print(query, json.dumps(task["data"]),)
        execute_query(query, (json.dumps(task["data"]),))
        
        # Create a directory for the task on GitHub
        for i, cmd in enumerate(cmds):
            script_content = cmd
            script_path = f"tasks/{task_id}/script_{i+1}.sh"

            # Encode the script content to base64
            encoded_content = base64.b64encode(script_content.encode()).decode()

            # Check if the file already exists to get its SHA
            file_sha = get_file_sha(github_owner, github_repo, script_path, headers)

            # GitHub API URL for creating/updating a file
            url = f"https://api.github.com/repos/{github_owner}/{github_repo}/contents/{script_path}"

            # Data payload
            data = {
                "message": f"Add script_{i+1}.sh for task {task_id}",
                "content": encoded_content
            }

            if file_sha:
                data["sha"] = file_sha

            # Make the PUT request to create/update the file on GitHub
            response = requests.put(url, headers=headers, json=data)

            if response.status_code == 201:
                print(f"Successfully created {script_path} on GitHub.")
            elif response.status_code == 200:
                print(f"Successfully updated {script_path} on GitHub.")
            else:
                print(f"Failed to create/update {script_path}. Response: {response.json()}")


def execute_query(query, params=None, fetch=False): #store_task_in_db(query):
    
    try:
        conn = psycopg2.connect(
            host=DB_HOST,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            port=DB_PORT
        )
        cur = conn.cursor()

        # Insert task details into the tasks table
        #insert_query = sql.SQL("""
            #INSERT INTO tasks (taskdetails) VALUES (%s)
        #""")
        #cur.execute(insert_query, [json.dumps(task["data"])])
        #query=sql.SQL(query)
        if params:
            cur.execute(query, params)
        else:
            cur.execute(query)

        if fetch:
            result = cur.fetchall()

        else:
            result = None
        
        conn.commit()
        cur.close()
        conn.close()
        return result
        
    except Exception as e:
        print(f"Error inserting task into database: {e}")
        return None

    

@app.route('/upload_tasks', methods=['POST'])
def upload_tasks():
    json_data = request.json
    # Replace with your GitHub details
    github_token = db_config['access_token']
    github_repo = db_config['repository_name']
    github_owner = db_config['username']

    upload_scripts_to_github(json_data, github_token, github_repo, github_owner)

    return jsonify({"status": "success"})

if __name__ == '__main__':
    app.run(debug=True)
